// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("fortify source"); }
int main(){
  announce();
  return lionss_run_workload("fortify-source");
}
