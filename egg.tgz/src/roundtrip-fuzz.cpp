// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("roundtrip fuzz\n", stdout);
  return lionss_run_workload("roundtrip-fuzz");
}
