// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("startup latency\n", stdout);
  return lionss_run_workload("startup-latency");
}
