# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(roundtrip-fuzz src/roundtrip-fuzz.cpp)
set_property(TARGET roundtrip-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(roundtrip-fuzz lionss pthread)

add_executable(allocation-bench src/allocation-bench.cpp)
set_property(TARGET allocation-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(allocation-bench lionss pthread)

add_executable(offline-tests src/offline-tests.cpp)
set_property(TARGET offline-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(offline-tests lionss pthread)

add_executable(gcc-12 src/gcc-12.cpp)
set_property(TARGET gcc-12 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-12 lionss pthread)

add_executable(perf-stat src/perf-stat.cpp)
set_property(TARGET perf-stat PROPERTY CXX_STANDARD 11)
target_link_libraries(perf-stat lionss pthread)

add_executable(infer-analyze src/infer-analyze.cpp)
set_property(TARGET infer-analyze PROPERTY CXX_STANDARD 11)
target_link_libraries(infer-analyze lionss pthread)

add_executable(symbol-visibility src/symbol-visibility.cpp)
set_property(TARGET symbol-visibility PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-visibility lionss pthread)

add_executable(tail-latency src/tail-latency.cpp)
set_property(TARGET tail-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(tail-latency lionss pthread)

add_executable(configure-minimal src/configure-minimal.cpp)
set_property(TARGET configure-minimal PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-minimal lionss pthread)

add_executable(pin-dependencies src/pin-dependencies.cpp)
set_property(TARGET pin-dependencies PROPERTY CXX_STANDARD 11)
target_link_libraries(pin-dependencies lionss pthread)

add_executable(dast-scan src/dast-scan.cpp)
set_property(TARGET dast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dast-scan lionss pthread)

add_executable(conan-package src/conan-package.cpp)
set_property(TARGET conan-package PROPERTY CXX_STANDARD 11)
target_link_libraries(conan-package lionss pthread)

add_executable(conformance-suite src/conformance-suite.cpp)
set_property(TARGET conformance-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(conformance-suite lionss pthread)

add_executable(rdtsc-calibration src/rdtsc-calibration.cpp)
set_property(TARGET rdtsc-calibration PROPERTY CXX_STANDARD 11)
target_link_libraries(rdtsc-calibration lionss pthread)

add_executable(out-of-tree-build src/out-of-tree-build.cpp)
set_property(TARGET out-of-tree-build PROPERTY CXX_STANDARD 11)
target_link_libraries(out-of-tree-build lionss pthread)

add_executable(cppcheck src/cppcheck.cpp)
set_property(TARGET cppcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(cppcheck lionss pthread)

add_executable(compatibility-tests src/compatibility-tests.cpp)
set_property(TARGET compatibility-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(compatibility-tests lionss pthread)

add_executable(core-dump-test src/core-dump-test.cpp)
set_property(TARGET core-dump-test PROPERTY CXX_STANDARD 11)
target_link_libraries(core-dump-test lionss pthread)

add_executable(line-coverage src/line-coverage.cpp)
set_property(TARGET line-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(line-coverage lionss pthread)

add_executable(coroutines-check src/coroutines-check.cpp)
set_property(TARGET coroutines-check PROPERTY CXX_STANDARD 11)
target_link_libraries(coroutines-check lionss pthread)

add_executable(timezone-tests src/timezone-tests.cpp)
set_property(TARGET timezone-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timezone-tests lionss pthread)

add_executable(startup-latency src/startup-latency.cpp)
set_property(TARGET startup-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(startup-latency lionss pthread)

add_executable(integration-tests src/integration-tests.cpp)
set_property(TARGET integration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(integration-tests lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(smoke src/smoke.cpp)
set_property(TARGET smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(smoke lionss pthread)

add_executable(ios-arm64 src/ios-arm64.cpp)
set_property(TARGET ios-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-arm64 lionss pthread)

add_executable(misra-check src/misra-check.cpp)
set_property(TARGET misra-check PROPERTY CXX_STANDARD 11)
target_link_libraries(misra-check lionss pthread)

add_executable(safestack src/safestack.cpp)
set_property(TARGET safestack PROPERTY CXX_STANDARD 11)
target_link_libraries(safestack lionss pthread)

add_executable(license-check src/license-check.cpp)
set_property(TARGET license-check PROPERTY CXX_STANDARD 11)
target_link_libraries(license-check lionss pthread)

add_executable(fortify-source src/fortify-source.cpp)
set_property(TARGET fortify-source PROPERTY CXX_STANDARD 11)
target_link_libraries(fortify-source lionss pthread)

